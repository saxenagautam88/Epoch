import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import FileCompareForm from "./FileCompareForm";

describe("FileCompareForm", () => {
  test("renders the form and validates file input", () => {
    render(<FileCompareForm />);

    const file1Input = screen.getByLabelText(/File 1/i);
    const file2Input = screen.getByLabelText(/File 2/i);
    const submitButton = screen.getByText(/Submit/i);

    // Check that both file inputs exist
    expect(file1Input).toBeInTheDocument();
    expect(file2Input).toBeInTheDocument();

    // Simulate empty form submission
    fireEvent.click(submitButton);
    expect(screen.getByText(/Both file fields are required/i)).toBeInTheDocument();
  });

  test("displays error for invalid file extensions", () => {
    render(<FileCompareForm />);

    const file1Input = screen.getByLabelText(/File 1/i);
    const file2Input = screen.getByLabelText(/File 2/i);
    const submitButton = screen.getByText(/Submit/i);

    const mockFile1 = new File(["content"], "file1.exe", { type: "application/x-msdownload" });
    const mockFile2 = new File(["content"], "file2.pdf", { type: "application/pdf" });

    fireEvent.change(file1Input, { target: { files: [mockFile1] } });
    fireEvent.change(file2Input, { target: { files: [mockFile2] } });
    fireEvent.click(submitButton);

    expect(screen.getByText(/Only .txt, .csv, and .json files are allowed/i)).toBeInTheDocument();
  });

  test("submits valid files and displays the response", async () => {
    render(<FileCompareForm />);

    const file1Input = screen.getByLabelText(/File 1/i);
    const file2Input = screen.getByLabelText(/File 2/i);
    const submitButton = screen.getByText(/Submit/i);

    const mockFile1 = new File(["content"], "file1.txt", { type: "text/plain" });
    const mockFile2 = new File(["content"], "file2.txt", { type: "text/plain" });

    fireEvent.change(file1Input, { target: { files: [mockFile1] } });
    fireEvent.change(file2Input, { target: { files: [mockFile2] } });

    // Mock axios or fetch call here if needed

    fireEvent.click(submitButton);

    // Assuming we mock axios/fetch and get a response
    // expect the response to be displayed on the screen
    // e.g. mock response could be { status: "success", differences: [...] }
  });
});



import React, { useState } from "react";
import axios from "axios";

const FileCompareForm = () => {
  const [file1, setFile1] = useState(null);
  const [file2, setFile2] = useState(null);
  const [response, setResponse] = useState(null);
  const [error, setError] = useState("");

  const validateFiles = () => {
    if (!file1 || !file2) {
      setError("Both file fields are required.");
      return false;
    }
    if (file1.type !== "text/plain" || file2.type !== "text/plain") {
      setError("Only .txt files are allowed.");
      return false;
    }
    setError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResponse(null);

    if (!validateFiles()) return;

    const formData = new FormData();
    formData.append("file", file1);
    formData.append("file", file2);

    try {
      const result = await axios.post("http://localhost:5000/compare", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setResponse(result.data);
    } catch (err) {
      setError("Error comparing files. Please try again.");
    }
  };

  return (
    <div>
      <h1>File Compare</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" accept=".txt" onChange={(e) => setFile1(e.target.files[0])} />
        <input type="file" accept=".txt" onChange={(e) => setFile2(e.target.files[0])} />
        <button type="submit">Compare</button>
      </form>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {response && (
        <div>
          <h2>Comparison Results:</h2>
          {Array.isArray(response.differences) && response.differences.length === 0 ? (
            <p>No differences found.</p>
          ) : (
            <ul>
              {Array.isArray(response.differences) ? (
                response.differences.map((diff, index) => (
                  <li key={index}>
                    Line {diff.line}:
                    <br />
                    <strong>File 1:</strong> {diff.file1 || "No line"}
                    <br />
                    <strong>File 2:</strong> {diff.file2 || "No line"}
                  </li>
                ))
              ) : (
                <li>{JSON.stringify(response)}</li> 
              )}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default FileCompareForm;


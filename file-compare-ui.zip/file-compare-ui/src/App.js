import React from 'react';
import FileCompareForm from './components/FileCompareForm'; // Ensure this path is correct

const App = () => {
  return (
    <div>
      <FileCompareForm />
    </div>
  );
};

export default App;  

# File Comparison API and UI

This project is a simple file comparison application built with a Node.js backend and a React frontend. It allows users to upload two text files and compare their contents, displaying any differences line by line.


## Features
- Upload two `.txt` files for comparison.
- Display line-by-line differences between the two files.
- Validate file input to ensure only text files are uploaded.
- User-friendly interface with error handling.

## Technologies
- **Backend**: Node.js, Express, Multer, CORS
- **Frontend**: React, Axios
- **Testing**: Jest (for unit tests)

## Setup

### Backend Setup
1. Clone the repository:

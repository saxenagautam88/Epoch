

const express = require("express");
const multer = require("multer");
const cors = require("cors");
const fs = require("fs");
const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(cors());

app.post("/compare", upload.array("file"), (req, res) => {
  if (!req.files || req.files.length < 2) {
    return res.status(400).json({ status: "error", message: "Two files are required." });
  }

  const file1Path = req.files[0].path;
  const file2Path = req.files[1].path;

  // Read the contents of the files
  fs.readFile(file1Path, 'utf8', (err1, data1) => {
    if (err1) return res.status(500).json({ status: "error", message: "Error reading file 1." });

    fs.readFile(file2Path, 'utf8', (err2, data2) => {
      if (err2) return res.status(500).json({ status: "error", message: "Error reading file 2." });

      // Log the contents of the files for debugging
      console.log("File 1 contents:", data1);
      console.log("File 2 contents:", data2);

      // Compare the contents of the two files
      const differences = compareFiles(data1, data2);

      // Clean up uploaded files
      fs.unlinkSync(file1Path);
      fs.unlinkSync(file2Path);

      // Return actual differences
      if (differences.length === 0) {
        return res.json({ status: "success", differences: [] });
      }
      return res.json({ status: "success", differences });
    });
  });
});

// Simple comparison function
function compareFiles(data1, data2) {
  const lines1 = data1.split("\n");
  const lines2 = data2.split("\n");

  const differences = [];
  const maxLength = Math.max(lines1.length, lines2.length);

  for (let i = 0; i < maxLength; i++) {
    const line1 = lines1[i] || '';
    const line2 = lines2[i] || '';

    if (line1 !== line2) {
      differences.push({
        line: i + 1,
        file1: line1,
        file2: line2
      });
    }
  }

  return differences;
}

app.listen(5000, () => console.log("Mock server running on port 5000"));

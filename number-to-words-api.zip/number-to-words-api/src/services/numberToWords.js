
const ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
const teens = ["", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
const tens = ["", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];
const hundreds = "hundred";

function convertNumberToWords(number) {
    if (number === 0) return "zero";
    if (number < 0 || number > 999 || !Number.isInteger(number)) return null;

    let word = "";

    if (Math.floor(number / 100) > 0) {
        word += ones[Math.floor(number / 100)] + " " + hundreds;
        number %= 100;
        if (number > 0) word += " ";
    }

    if (number > 10 && number < 20) {
        word += teens[number - 10];
    } else {
        if (Math.floor(number / 10) > 0) {
            word += tens[Math.floor(number / 10)];
            number %= 10;
            if (number > 0) word += "-";
        }
        word += ones[number];
    }

    return word;
}

module.exports = convertNumberToWords;


const express = require('express');
const convertNumberToWords = require('../services/numberToWords');
const router = express.Router();

router.post('/convert', (req, res) => {
    const { number } = req.body;

    if (typeof number !== 'number') {
        return res.status(400).json({ status: "error", message: "Invalid input type" });
    }

    const words = convertNumberToWords(number);

    if (words === null) {
        return res.status(400).json({ status: "error", message: "Number must be between 0 and 999" });
    }

    return res.json({ status: "success", words });
});

router.get('/', (req, res) => {
    res.status(200).send('Welcome to the Number to Words API. Use the /api/convert endpoint to convert numbers to words.');
});


module.exports = router;

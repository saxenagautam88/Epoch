# Number to Words API

## Overview
This is a simple RESTful API that converts a given number into its word representation. The API supports numbers from 0 to 999.

## Prerequisites
- Node.js
- npm

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/number-to-words-api.git
   cd number-to-words-api

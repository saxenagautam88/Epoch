
const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../src/app');

chai.should();
chai.use(chaiHttp);

describe('Number to Words API', () => {
    it('should return the words for a valid number', (done) => {
        chai.request(app)
            .post('/api/convert')
            .send({ number: 123 })
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('status').eql('success');
                res.body.should.have.property('words').eql('one hundred twenty-three');
                done();
            });
    });

    it('should return an error for an invalid number', (done) => {
        chai.request(app)
            .post('/api/convert')
            .send({ number: -1 })
            .end((err, res) => {
                res.should.have.status(400);
                res.body.should.be.a('object');
                res.body.should.have.property('status').eql('error');
                res.body.should.have.property('message').eql('Number must be between 0 and 999');
                done();
            });
    });

    it('should return an error for a non-integer input', (done) => {
        chai.request(app)
            .post('/api/convert')
            .send({ number: "abc" })
            .end((err, res) => {
                res.should.have.status(400);
                res.body.should.be.a('object');
                res.body.should.have.property('status').eql('error');
                res.body.should.have.property('message').eql('Invalid input type');
                done();
            });
    });
});
